import React, { useContext, useState } from 'react';
import { OrderContext } from '../context/OrderContext';

const OrderForm = () => {
    const { addOrder } = useContext(OrderContext);
    const [form, setForm] = useState({ orderName: '', price: '', promo: false });
    const [errors, setErrors] = useState({});

    const validate = () => {
        const newErrors = {};

        // Regular expression to check for special characters
        const specialCharRegex = /[^a-zA-Z0-9 ]/;

        if (!form.orderName) {
            newErrors.orderName = 'Order name is required';
        } else if (specialCharRegex.test(form.orderName)) {
            newErrors.orderName = 'Order name cannot contain special characters';
        }

        if (!form.price || form.price <= 0) {
            newErrors.price = 'Price must be positive';
        }

        // You can add more validation rules here
        return newErrors;
    };

    const handleChange = (e) => {
        const { name, value, checked, type } = e.target;
        setForm((prevForm) => ({
            ...prevForm,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const newErrors = validate();
        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
        } else {
            addOrder(form);
            setForm({ orderName: '', price: '', promo: false });
            setErrors({});
        }
    };

    return (
        <form onSubmit={handleSubmit} className="flex flex-wrap border-outset p-1 bg-white rounded shadow-md">
            <div className="flex flex-col flex-grow mb-4 basis-2/6">
                <label htmlFor="orderName" className="block text-center bg-custom-blue text-white py-4 text-gray-700">
                    Order Item
                </label>
                <input
                    type="text"
                    name="orderName"
                    value={form.orderName}
                    onChange={handleChange}
                    className="w-3/4 p-2 self-center border border-gray-300 rounded mt-1"
                    placeholder="Order Item"
                    required
                />
                <div className="text-red-500 text-sm w-full">
                    {errors.orderName}
                </div>
            </div>
            <div className="flex flex-col flex-grow mb-4 basis-2/6">
                <label htmlFor="price" className="block text-center bg-custom-blue text-white py-4 text-gray-700">
                    Price
                </label>
                <input
                    type="number"
                    name="price"
                    value={form.price}
                    onChange={handleChange}
                    className="w-3/4 p-2 self-center border border-gray-300 rounded mt-1"
                    placeholder="Price"
                    required
                />
                <div className="text-red-500 text-sm w-full">
                    {errors.price}
                </div>
            </div>
            <div className="flex flex-col flex-grow mb-4 basis-1/6">
                <label htmlFor="promo" className="block text-center bg-custom-blue text-white py-4 text-gray-700">
                    On 5% Promo?
                </label>
                <input
                    type="checkbox"
                    name="promo"
                    checked={form.promo}
                    onChange={handleChange}
                    className="h-full mt-2 self-center"
                />
            </div>
            <div className="flex flex-col flex-grow mb-4 basis-1/6">
                <label htmlFor="promo" className="block text-center bg-custom-blue text-white py-4 text-gray-700">
                    Actions
                </label>
                <button type="submit" className="py-1 px-3 w-6/7 bg-custom-blue text-white rounded-xl mt-4 mx-auto hover:bg-blue-700">
                    Place Order
                </button>
            </div>
        </form>
    );
};

export default OrderForm;