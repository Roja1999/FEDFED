package com.hanna.ws.impl;

import com.hanna.ws.entity.CafeClerk;
import com.hanna.ws.entity.Order;

public class RegularBill extends OrderBill {

    public RegularBill(CafeClerk clerk) {
        super(clerk);
    }

    @Override
    public double getTotalBill() {
        return getOrderList().stream()
                .mapToDouble(Order::getPrice)
                .sum();
    }
}
