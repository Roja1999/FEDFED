import { configureStore } from '@reduxjs/toolkit';
import orderReducer from './reducers';

const store = configureStore({
    reducer: {
        orders: orderReducer,
    },
});

export default store;